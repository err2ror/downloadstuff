from sys import argv as args
from shutil import get_terminal_size as gts
te=0
conf=0
def rand(start):
    if start < 0:
        raise ValueError("Value can't be under zero")
        exit(1)
    x=start+3
    y=0
    while x > 0:
        x=x/x-1
        print(x)
        y+=1
    return y
if len(args)==2 and args[1]=="resize":
    while True:
        te=int(input("screen size"))
        print("@"*te) 
        if input("is it good? [y/n]")=="y":
            conf=open(".asdf.asdf","w")
            conf.write(str(te-1))
            exit(0)
#lens=int(open(".asdf.asdf").read())
lens=gts(fallback=(80,24)).columns
#that is literally the only f**king change
def printright(z):
    print((" "*(lens-len(str(z))))+str(z))
def retr(z):
    return (" "*(lens-len(str(z))))+str(z)
